import { useEffect, useState } from "react";

const API = "http://localhost:8080/api/chat";

const languages = [
  { value: "English", label: "English" },
  { value: "Telugu", label: "తెలుగు (Telugu)" },
  { value: "Hindi", label: "हिंदी (Hindi)" }
];

function App() {
  const [language, setLanguage] = useState("English");
  const [message, setMessage] = useState("");
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    loadHistory();
  }, []);

  async function loadHistory() {
    setLoadingHistory(true);
    try {
      const response = await fetch(`${API}/history`);
      if (!response.ok) throw new Error("Could not load conversation history.");
      const data = await response.json();
      setHistory(data);
    } catch (err) {
      setError("Backend is not reachable. Start the Spring Boot server.");
    } finally {
      setLoadingHistory(false);
    }
  }

  async function sendMessage(event) {
    event.preventDefault();
    const cleanMessage = message.trim();

    if (!cleanMessage) {
      setError("Please enter a banking question.");
      return;
    }

    if (cleanMessage.length > 500) {
      setError("Message must be 500 characters or less.");
      return;
    }

    setError("");
    setLoading(true);

    try {
      const response = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          language,
          message: cleanMessage
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Request failed.");
      }

      setHistory((old) => [data, ...old]);
      setMessage("");
    } catch (err) {
      setError(err.message || "Unable to send your question.");
    } finally {
      setLoading(false);
    }
  }

  async function clearHistory() {
    if (!window.confirm("Clear all conversation history?")) return;

    try {
      const response = await fetch(`${API}/history`, { method: "DELETE" });
      if (!response.ok) throw new Error("Could not clear history.");
      setHistory([]);
      setError("");
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="app">
      <header className="header">
        <div>
          <div className="brand">🏦 RuralBank Assist</div>
          <p>Simple banking help in your language</p>
        </div>
        <span className="status"><i /> Online</span>
      </header>

      <main className="container">
        <section className="hero">
          <div>
            <span className="badge">LANGUAGE TRANSLATION CHATBOT</span>
            <h1>Ask banking questions in a language you understand.</h1>
            <p>
              Get simple guidance about accounts, loans, ATMs and digital
              payments. This demo supports English, Telugu and Hindi.
            </p>
          </div>
        </section>

        <section className="chat-card">
          <div className="card-title">
            <div>
              <h2>Banking Chat</h2>
              <span>Ask a question below</span>
            </div>
            <button className="clear-btn" onClick={clearHistory} disabled={!history.length}>
              Clear history
            </button>
          </div>

          {error && <div className="error">{error}</div>}

          <div className="messages">
            {loadingHistory ? (
              <div className="empty">Loading conversation history...</div>
            ) : history.length === 0 ? (
              <div className="empty">
                <div className="empty-icon">💬</div>
                <strong>Start a conversation</strong>
                <span>Try: “How can I check my account balance?”</span>
              </div>
            ) : (
              history.map((item) => (
                <div className="conversation" key={item.id}>
                  <div className="message user">
                    <span className="label">You · {item.language}</span>
                    <p>{item.userMessage}</p>
                  </div>
                  <div className="message bot">
                    <span className="label">RuralBank Assist</span>
                    <p>{item.botResponse}</p>
                    <small>{new Date(item.createdAt).toLocaleString()}</small>
                  </div>
                </div>
              ))
            )}

            {loading && (
              <div className="typing">
                <span /> <span /> <span /> Translating...
              </div>
            )}
          </div>

          <form className="composer" onSubmit={sendMessage}>
            <div className="controls">
              <label>
                Language
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  disabled={loading}
                >
                  {languages.map((item) => (
                    <option key={item.value} value={item.value}>
                      {item.label}
                    </option>
                  ))}
                </select>
              </label>
              <div className="examples">
                <span>Try asking:</span>
                <button type="button" onClick={() => setMessage("How can I check my account balance?")}>
                  Account balance
                </button>
                <button type="button" onClick={() => setMessage("How can I apply for a loan?")}>
                  Loan
                </button>
                <button type="button" onClick={() => setMessage("How do I use an ATM?")}>
                  ATM
                </button>
              </div>
            </div>

            <div className="input-row">
              <textarea
                value={message}
                onChange={(e) => {
                  setMessage(e.target.value);
                  if (error) setError("");
                }}
                placeholder="Type your banking question..."
                maxLength={500}
                rows={3}
                disabled={loading}
              />
              <button className="send" type="submit" disabled={loading || !message.trim()}>
                {loading ? "Sending..." : "Send ➜"}
              </button>
            </div>

            <div className="counter">{message.length}/500</div>
          </form>
        </section>
      </main>

      <footer>Educational demo · Do not share PINs, passwords, OTPs or other confidential banking information.</footer>
    </div>
  );
}

export default App;
